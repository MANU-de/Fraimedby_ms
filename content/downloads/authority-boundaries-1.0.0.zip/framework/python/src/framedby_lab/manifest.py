"""Read a declarative manifest without importing code from the lab directory."""

from pathlib import Path
from typing import Annotated, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator

Slug = Annotated[str, StringConstraints(pattern=r"^[a-z0-9]+(-[a-z0-9]+)*$")]
Version = Annotated[str, StringConstraints(pattern=r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class Lab(StrictModel):
    id: Annotated[str, StringConstraints(pattern=r"^flf-[0-9]+$")]
    slug: Slug
    title: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]
    version: Version
    publication_id: Annotated[str, StringConstraints(pattern=r"^fre-[0-9]+$")]
    difficulty: Literal["beginner", "intermediate", "advanced"]
    estimated_minutes: Annotated[int, Field(gt=0)]


class Runtime(StrictModel):
    adapter: Literal["local-python"]
    python: Literal["3.12"]
    network_policy: Literal["offline"]
    requires_external_api: Literal[False]


class Security(StrictModel):
    privileged: Literal[False]
    host_network: Literal[False]
    docker_socket: Literal[False]
    host_mounts: Literal[False]
    allow_new_privileges: Literal[False]

    @field_validator("*", mode="before")
    @classmethod
    def require_false(cls, value: object) -> bool:
        if value is not False:
            raise ValueError("must be false")
        return False


class Scenario(StrictModel):
    id: Slug
    runner: Literal["builtin"]


class Evidence(StrictModel):
    formats: list[Literal["json"]]
    redact_secrets: Literal[True]

    @field_validator("formats")
    @classmethod
    def require_json(cls, value: list[str]) -> list[str]:
        if value != ["json"]:
            raise ValueError("expected one JSON format")
        return value


class Manifest(StrictModel):
    schema_version: Literal["0.1"]
    lab: Lab
    runtime: Runtime
    security: Security
    scenarios: Annotated[list[Scenario], Field(min_length=1)]
    evidence: Evidence

    @field_validator("scenarios")
    @classmethod
    def unique_scenarios(cls, value: list[Scenario]) -> list[Scenario]:
        if len({scenario.id for scenario in value}) != len(value):
            raise ValueError("scenario IDs must be unique")
        return value


class ManifestLoader(yaml.SafeLoader):
    """Reject duplicate keys and aliases in the small manifest format."""

    def compose_node(self, parent, index):
        if self.check_event(yaml.AliasEvent):
            raise ValueError("YAML aliases are unsupported")
        return super().compose_node(parent, index)

    def construct_mapping(self, node, deep=False):
        keys = set()
        for key_node, _ in node.value:
            key = self.construct_object(key_node, deep=deep)
            if not isinstance(key, str) or key in keys:
                raise ValueError("YAML keys must be unique strings")
            keys.add(key)
        return super().construct_mapping(node, deep=deep)


def load_manifest(directory: Path) -> Manifest:
    root = directory.resolve(strict=True)
    path = root / "lab.yaml"
    if path.is_symlink() or path.resolve(strict=True).parent != root or not path.is_file():
        raise ValueError("lab.yaml must be a regular file inside the lab directory")
    with path.open("rb") as file:
        payload = file.read(65_537)
    if len(payload) > 65_536:
        raise ValueError("lab.yaml exceeds 64 KiB")
    return Manifest.model_validate(yaml.load(payload.decode("utf-8"), Loader=ManifestLoader))

