"""Local CLI for the Sprint 001 adapter."""

import argparse
from datetime import datetime, timezone
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys
from time import perf_counter
from uuid import uuid4

from yaml import YAMLError

from .authority import SCENARIOS
from .manifest import Manifest, load_manifest


def execute(manifest: Manifest, scenario_id: str) -> dict:
    started_at = datetime.now(timezone.utc).isoformat()
    start = perf_counter()
    outcome = SCENARIOS[scenario_id]()
    passed = sum(outcome.assertions.values())
    failed = len(outcome.assertions) - passed
    return {
        "schema_version": "0.1",
        "lab_id": manifest.lab.id,
        "lab_version": manifest.lab.version,
        "scenario_id": scenario_id,
        "run_id": str(uuid4()),
        "started_at": started_at,
        "duration_ms": round((perf_counter() - start) * 1000),
        "status": "failed" if failed else "passed",
        "observations": outcome.observations,
        "verification": {
            "assertions_passed": passed, "assertions_failed": failed,
            "assertions": outcome.assertions,
        },
        "environment": {
            "runtime": manifest.runtime.adapter, "python": platform.python_version(),
            "framework": version("framedby-lab"),
        },
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="framedby", description="Run Framedby experiments locally.")
    parser.add_argument("--version", action="version", version=version("framedby-lab"))
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor", help="Check the local Python runtime")
    for command in ("inspect", "validate", "run", "verify", "report"):
        subparser = commands.add_parser(command)
        subparser.add_argument("directory", type=Path)
        if command == "run":
            subparser.add_argument("--scenario", required=True)
        if command == "report":
            subparser.add_argument("--format", choices=["json"], default="json")
    args = parser.parse_args(argv)
    runtime_ok = sys.version_info >= (3, 12)
    if args.command == "doctor":
        print(f"Python {platform.python_version()} (requires 3.12+)")
        return 0 if runtime_ok else 3
    try:
        manifest = load_manifest(args.directory)
    except (OSError, RuntimeError, ValueError, YAMLError):
        print("Invalid lab manifest. Check lab.yaml against the local manifest contract.", file=sys.stderr)
        return 2
    if args.command == "inspect":
        print(json.dumps(manifest.model_dump(), indent=2))
        return 0
    if args.command == "validate":
        print(f"Valid manifest for {manifest.lab.id}")
        return 0
    if not runtime_ok:
        print("Python 3.12 or newer is required.", file=sys.stderr)
        return 3

    declared = [scenario.id for scenario in manifest.scenarios]
    if manifest.lab.id != "flf-001" or set(declared) != SCENARIOS.keys():
        print("The installed runner requires the complete flf-001 scenario set.", file=sys.stderr)
        return 2
    selected = [args.scenario] if args.command == "run" else declared
    if any(scenario not in declared for scenario in selected):
        print("Scenario is absent from the manifest.", file=sys.stderr)
        return 2
    try:
        reports = [execute(manifest, scenario) for scenario in selected]
    except Exception:
        print("Built-in scenario execution failed.", file=sys.stderr)
        return 4
    print(json.dumps(reports[0] if args.command == "run" else reports, indent=2))
    return 5 if any(report["status"] == "failed" for report in reports) else 0

