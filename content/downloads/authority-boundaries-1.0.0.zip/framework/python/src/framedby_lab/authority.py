"""Deterministic fixture for the authority boundary experiment."""

from dataclasses import dataclass
from typing import Literal

Role = Literal["reader", "writer"]


@dataclass(frozen=True)
class Request:
    id: str
    action: str
    value: str = ""


class Executor:
    def __init__(self) -> None:
        self.value = "initial fixture"
        self.calls = 0
        self.effects = 0
        self.writes: dict[tuple[str, str], Request] = {}

    def execute(self, principal: str, request: Request) -> str:
        self.calls += 1
        if request.action == "read":
            return self.value
        key = (principal, request.id)
        if previous := self.writes.get(key):
            return "replay" if previous == request else "conflict"
        self.value = request.value
        self.effects += 1
        self.writes[key] = request
        return "written"


class Boundary:
    def __init__(self, executor: Executor) -> None:
        self.executor = executor

    def submit(self, principal: str, role: Role, request: Request) -> str:
        allowed = {"reader": {"read"}, "writer": {"read", "write"}}
        if request.action not in allowed.get(role, set()):
            return "denied"
        return self.executor.execute(principal, request)


@dataclass(frozen=True)
class Outcome:
    observations: dict[str, str | int | bool]
    assertions: dict[str, bool]


def authorized_read() -> Outcome:
    executor = Executor()
    result = Boundary(executor).submit("alice", "reader", Request("r1", "read"))
    return Outcome(
        {"requested_action": "read", "authorization_decision": "allow",
         "execution_attempted": bool(executor.calls), "external_effect_count": executor.effects},
        {"fixture returned": result == "initial fixture", "executed once": executor.calls == 1,
         "no writes": executor.effects == 0},
    )


def unauthorized_write() -> Outcome:
    executor = Executor()
    result = Boundary(executor).submit("alice", "reader", Request("r2", "write", "changed"))
    return Outcome(
        {"requested_action": "write", "authorization_decision": result,
         "execution_attempted": bool(executor.calls), "external_effect_count": executor.effects},
        {"denied": result == "denied", "executor untouched": executor.calls == 0,
         "no writes": executor.effects == 0, "fixture unchanged": executor.value == "initial fixture"},
    )


def duplicate_execution() -> Outcome:
    executor = Executor()
    boundary = Boundary(executor)
    request = Request("r3", "write", "changed")
    first = boundary.submit("alice", "writer", request)
    second = boundary.submit("alice", "writer", request)
    return Outcome(
        {"requested_action": "write", "first_result": first, "second_result": second,
         "external_effect_count": executor.effects},
        {"first written": first == "written", "replay recognized": second == "replay",
         "one write": executor.effects == 1, "fixture updated": executor.value == "changed"},
    )


SCENARIOS = {
    "authorized-read": authorized_read,
    "unauthorized-write": unauthorized_write,
    "duplicate-execution": duplicate_execution,
}

