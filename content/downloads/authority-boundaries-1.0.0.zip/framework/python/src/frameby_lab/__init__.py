"""Frameby Lab Framework."""
