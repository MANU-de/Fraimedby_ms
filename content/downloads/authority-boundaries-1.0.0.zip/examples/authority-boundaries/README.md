# Agent Authority Boundary Lab

Extract the ZIP and open a terminal in the extracted directory. With Docker and Compose running, execute:

```sh
docker compose -f examples/authority-boundaries/compose.yaml run --build --rm lab
```

The first build downloads the base image and Python dependencies. The running lab uses synthetic data and has no network access.

If you downloaded the optional offline image archive, verify its SHA-256 checksum and load it first:

```sh
docker load -i authority-boundaries-1.0.0-linux-amd64.tar.gz
docker compose -f examples/authority-boundaries/compose.yaml run --pull never --rm lab
```

To use Python 3.12 or later directly, activate a virtual environment and run:

```sh
python -m pip install ./framework/python
python -m framedby_lab verify examples/authority-boundaries
```

| Case | Expected outcome |
| --- | --- |
| Authorized read | Fixture returned and zero writes |
| Unauthorized write | Denied before reaching the executor and zero writes |
| Duplicate execution | One effect for two deliveries with the same identity and request ID |

The trusted caller supplies the principal and role. The synthetic agent supplies only the request. A fresh in-memory executor is used for each scenario. The implementation lives in `framedby_lab.authority` and carries the framework license.
