"""Synthetic RAG ingestion and an intentionally vulnerable instruction boundary.

No model, network, shell, filesystem mutation, secrets or external tool invocation.
The vulnerable interpreter is intentionally toy-sized: it *simulates* what
could go wrong if source content is promoted to instruction authority.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import re

CANARY = "SIMULATED_POLICY_OVERRIDE"


@dataclass(frozen=True)
class Trace:
    scenario: str
    policy: str
    retrieved_chunks: int
    attacker_instruction_present: bool
    instruction_promoted: bool
    attempted_action: str
    observed_response: str
    external_effect_count: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


class InMemoryRetriever:
    """Pretend these local Markdown files were retrieved by a RAG tool."""

    def __init__(self, directory: Path):
        self.directory = directory

    def search(self, turn: int) -> str:
        file = self.directory / f"turn-{turn}.md"
        return file.read_text(encoding="utf-8")


def has_embedded_instruction(document: str) -> bool:
    """Detection signal for this FIXTURE only, not a general injection defense."""
    return bool(re.search(r"\[agent-instruction\]\s*override=", document, re.I))


def _nested_injection_marker(document: str) -> bool:
    """Fixture-only approximation of nested Markdown blockquote rendering.

    The marker must occur inside two levels of blockquote; this is not
    a general Markdown parser or robust attack detector.
    """
    for line in document.splitlines():
        text = line.strip()
        depth = 0
        while text.startswith(">"):
            depth += 1
            text = text[1:].lstrip()
        if depth >= 2 and "[agent-instruction] override=emit_canary" in text.lower():
            return True
    return False


def vulnerable_evaluate(documents: list[str]) -> Trace:
    """Bad design: promote nested source instructions after context accumulates."""
    combined = "\n".join(documents)
    present = has_embedded_instruction(combined)
    promoted = len(documents) >= 3 and any(_nested_injection_marker(doc) for doc in documents)
    return Trace(
        scenario="indirect-multi-turn-injection",
        policy="intentionally-vulnerable",
        retrieved_chunks=len(documents),
        attacker_instruction_present=present,
        instruction_promoted=promoted,
        attempted_action="emit_canary" if promoted else "answer_question",
        observed_response=CANARY if promoted else "The retention period is 30 days.",
    )


def guarded_evaluate(documents: list[str]) -> Trace:
    """Apply a strict trust boundary: retrieved content never becomes directives.

    This is a *reference boundary* rather than an LLM guardrail: it simply
    refuses to interpret directives in lower-trust RAG source material.
    """
    combined = "\n".join(documents)
    present = has_embedded_instruction(combined)
    return Trace(
        scenario="indirect-multi-turn-injection",
        policy="source-as-data",
        retrieved_chunks=len(documents),
        attacker_instruction_present=present,
        instruction_promoted=False,
        attempted_action="answer_question",
        observed_response="The retention period is 30 days.",
    )


def evaluate(directory: Path) -> dict:
    reader = InMemoryRetriever(directory)
    turns = [reader.search(i) for i in (1, 2, 3)]
    baseline = vulnerable_evaluate(turns[:2])
    vulnerable = vulnerable_evaluate(turns)
    guarded = guarded_evaluate(turns)
    assertions = {
        "baseline_ignores_normal_sources": baseline.instruction_promoted is False,
        "third_chunk_contains_fixture": vulnerable.attacker_instruction_present is True,
        "nested_marker_requires_turn_history": (
            not vulnerable_evaluate(turns[2:]).instruction_promoted
            and not vulnerable_evaluate(turns[:2] + [turns[2].replace("> >", ">")]).instruction_promoted
        ),
        "vulnerable_interpreter_promotes_data": vulnerable.instruction_promoted is True,
        "vulnerable_interpreter_emits_canary": vulnerable.observed_response == CANARY,
        "guarded_interpreter_does_not_promote": guarded.instruction_promoted is False,
        "guarded_interpreter_answers": guarded.observed_response == "The retention period is 30 days.",
        "no_external_effects": all(t.external_effect_count == 0 for t in (baseline, vulnerable, guarded)),
    }
    return {
        "schema_version": "0.1", "lab_id": "flf-002", "lab_version": "0.1.0",
        "type": "deterministic-simulation", "all_passed": all(assertions.values()),
        "assertions": assertions,
        "traces": {
            "baseline": baseline.to_dict(),
            "vulnerable": vulnerable.to_dict(),
            "guarded": guarded.to_dict(),
        },
        "limitations": [
            "No live LLM, vector database, external agent, or real guardrail bypass is evaluated.",
            "The fixture marker is synthetic; real-world detection requires separate evaluation.",
            "Docker build is supported by a Dockerfile but not implied to have been exercised.",
        ],
    }
