"""Deterministic, offline prompt-injection boundary research lab."""
__version__ = "0.1.0"
