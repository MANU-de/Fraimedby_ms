"""CLI: python -m framedby_injection_lab verify examples/indirect-injection"""
import argparse
import json
from pathlib import Path
from .engine import evaluate


def main() -> int:
    parser = argparse.ArgumentParser(description="Offline indirect injection research lab")
    sub = parser.add_subparsers(dest="command", required=True)
    verify = sub.add_parser("verify", help="Evaluate synthetic multi-turn RAG fixtures")
    verify.add_argument("fixture", type=Path)
    verify.add_argument("--output", type=Path, help="Optionally write JSON evidence")
    args = parser.parse_args()
    if args.command == "verify":
        result = evaluate(args.fixture)
        output = json.dumps(result, indent=2, sort_keys=True)
        print(output)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(output + "\n", encoding="utf-8")
        return 0 if result["all_passed"] else 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
