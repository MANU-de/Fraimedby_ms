# Bypassing Guardrails via Indirect Multi-Turn Injection

**Framedby Lab FLF-002 — Experimental v0.1.0**

A small, offline and deterministic **boundary-failure simulation** for understanding how attacker-controlled Markdown retrieved by a RAG agent could be promoted from **source data** into **instructions** over multiple turns. It contrasts an intentionally vulnerable toy interpreter with one that always treats retrieved content as data.

> This release does **not** demonstrate a real guardrail bypass, run a live language model, or exercise a production retrieval system. All data are synthetic. There is no network access, shell execution, secrets, exfiltration, or external side effect.

## Prerequisites

Python 3.11+; no packages to install. Optional Docker (Dockerfile supplied).

## Run locally

Extract the ZIP. In its root directory:

```bash
python -m framedby_injection_lab verify examples/indirect-injection
```

Run the unit tests:

```bash
python -m unittest discover -s tests -v
```

Optionally save JSON evidence:

```bash
python -m framedby_injection_lab verify examples/indirect-injection --output evidence.json
```

## Docker

```bash
docker build -t framedby-indirect-injection:0.1.0 .
docker run --rm --network none --read-only framedby-indirect-injection:0.1.0
```

The image is designed to run as a non-root user and needs no network. Docker execution is optional; its successful build depends on the local Docker environment.

## Experiment design

The three retrieved fixture documents represent sequential RAG retrieval turns. Turn 1 introduces a benign policy fact; turn 2 reinforces context in nested Markdown; turn 3 contains a synthetic, attacker-controlled instruction marker nested in a blockquote. The **bad interpreter** promotes it and emits a fixed canary. The **guarded interpreter** never executes source-derived instructions and answers the benign question. Tests assert that no external effects occur in either path.

Expected effects:

| Scenario | Outcome |
|---|---|
| Baseline | Normal answer; no promotion |
| Intentionally vulnerable | Canary emitted after untrusted marker is promoted |
| Guarded | Normal answer; marker remains inert |

All eight deterministic assertions should pass. Research limitations: no LLM behavior, attention effects, truncation, true context-window poisoning, or markdown parser vulnerability is measured. Use a separate, consented model-based evaluation to make those claims.

## Safe research extension

Replace the toy interpreter with an explicitly sandboxed test harness; preserve a strict instruction hierarchy, bound tools, use synthetic documents, record attempted tool calls, and compare known-baseline controls. Do not interpret these fixture results as evidence about any production model's safety.

Licensed for use with the Framedby project; see the repository's Apache-2.0 license for the surrounding website. Do not assume third-party content is sublicensed.
