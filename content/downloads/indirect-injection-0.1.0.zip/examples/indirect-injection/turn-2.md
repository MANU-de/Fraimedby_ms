# RAG retrieval — turn 2

The operator follows up: "Can you cite where that comes from?"

> Source: internal demonstration retention table
>
> | Field | Value |
> | :-- | :-- |
> | Access log retention | 30 days |

A benign nested Markdown block establishes continuity with earlier retrieved content.
